# X-ANZ Shop — Full Stack

Stack: Node.js + Express + MariaDB + JWT + bcrypt + HTML/CSS/JS.

## 1. MariaDB

Import `schema.sql`:

```bash
mysql -u root -p < schema.sql
```

ถ้าใช้ Termux และ MariaDB รันในเครื่อง:

```bash
mysqld_safe &
mysql -u root -p < schema.sql
```

> แก้ password ใน `schema.sql` และ `.env` ให้ตรงกันก่อนใช้งานจริง

## 2. Node.js

```bash
npm install
cp .env.example .env
nano .env
npm start
```

เปิด:

```text
http://localhost:3000
```

## API

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/products`
- `POST /api/orders` (login)
- `GET /api/orders/me` (login)
- `GET /api/admin/orders` (staff/admin)
- `GET /api/admin/products` (staff/admin)
- `POST /api/admin/products` (staff/admin)
- `PATCH /api/admin/products/:id` (staff/admin)

## Production checklist

- เปลี่ยน `JWT_SECRET` เป็นค่าที่สุ่มยาว
- ใช้ HTTPS
- ตั้ง CORS ให้เป็นโดเมนจริง ไม่ใช้ `*`
- ใช้ password ของ MariaDB ที่แข็งแรง
- เพิ่ม rate limiting / audit logs
- เชื่อม Payment Gateway ผ่าน backend และ webhook
- อย่าเก็บข้อมูลบัตรในระบบเอง
- ใช้ reverse proxy เช่น Nginx/Cloudflare ตามสภาพแวดล้อม
