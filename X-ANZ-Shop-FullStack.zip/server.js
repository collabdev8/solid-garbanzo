require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const path = require("path");
const mariadb = require("mariadb");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-secret";

const pool = mariadb.createPool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  connectionLimit: 5
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN || true }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

async function db(sql, params = []) {
  let conn;
  try {
    conn = await pool.getConnection();
    return await conn.query(sql, params);
  } finally {
    if (conn) conn.release();
  }
}

function signUser(user) {
  return jwt.sign(
    { id: Number(user.id), email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: "7d" }
  );
}

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "กรุณาเข้าสู่ระบบ" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Token ไม่ถูกต้องหรือหมดอายุ" });
  }
}

function adminOnly(req, res, next) {
  if (!["admin", "staff"].includes(req.user.role)) {
    return res.status(403).json({ error: "ไม่มีสิทธิ์" });
  }
  next();
}

app.get("/api/health", async (req, res) => {
  try {
    await db("SELECT 1 AS ok");
    res.json({ ok: true, database: "connected" });
  } catch (e) {
    res.status(503).json({ ok: false, database: "disconnected" });
  }
});

app.post("/api/auth/register", async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 8) {
    return res.status(400).json({ error: "กรอกข้อมูลให้ครบ และรหัสผ่านอย่างน้อย 8 ตัวอักษร" });
  }
  try {
    const exists = await db("SELECT id FROM users WHERE email=?", [email.toLowerCase().trim()]);
    if (exists.length) return res.status(409).json({ error: "อีเมลนี้มีบัญชีแล้ว" });
    const hash = await bcrypt.hash(password, 12);
    const result = await db(
      "INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'user')",
      [name.trim(), email.toLowerCase().trim(), hash]
    );
    const user = { id: Number(result.insertId), name, email: email.toLowerCase().trim(), role: "user" };
    res.status(201).json({ token: signUser(user), user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "สมัครสมาชิกไม่สำเร็จ" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const rows = await db("SELECT id,name,email,password_hash,role FROM users WHERE email=?", [String(email || "").toLowerCase().trim()]);
    if (!rows.length || !(await bcrypt.compare(password || "", rows[0].password_hash))) {
      return res.status(401).json({ error: "อีเมลหรือรหัสผ่านไม่ถูกต้อง" });
    }
    const u = rows[0];
    const user = { id: Number(u.id), name: u.name, email: u.email, role: u.role };
    res.json({ token: signUser(user), user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "เข้าสู่ระบบไม่สำเร็จ" });
  }
});

app.get("/api/products", async (req, res) => {
  const q = String(req.query.q || "").trim();
  const category = String(req.query.category || "").trim();
  const rows = await db(
    `SELECT id,name,category,price,image,stock,description,active
     FROM products
     WHERE active=1
       AND (?='' OR name LIKE CONCAT('%',?,'%') OR category LIKE CONCAT('%',?,'%'))
       AND (?='' OR category=?)
     ORDER BY id DESC`,
    [q,q,q,category,category]
  );
  res.json(rows);
});

app.post("/api/orders", auth, async (req, res) => {
  const { items, shipping } = req.body;
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: "ไม่มีสินค้า" });
  if (!shipping?.name || !shipping?.phone || !shipping?.address) {
    return res.status(400).json({ error: "ข้อมูลจัดส่งไม่ครบ" });
  }

  let conn;
  try {
    conn = await pool.getConnection();
    await conn.beginTransaction();

    let total = 0;
    const normalized = [];

    for (const item of items) {
      const id = Number(item.productId);
      const qty = Number(item.quantity);
      if (!Number.isInteger(id) || !Number.isInteger(qty) || qty < 1) throw new Error("รายการสินค้าไม่ถูกต้อง");

      const rows = await conn.query(
        "SELECT id,name,price,stock FROM products WHERE id=? AND active=1 FOR UPDATE",
        [id]
      );
      if (!rows.length) throw new Error("ไม่พบสินค้า");
      const p = rows[0];
      if (p.stock < qty) throw new Error(`สินค้า ${p.name} มีไม่พอ`);

      const subtotal = Number(p.price) * qty;
      total += subtotal;
      normalized.push({ productId: id, name: p.name, price: Number(p.price), quantity: qty, subtotal });

      await conn.query("UPDATE products SET stock=stock-? WHERE id=?", [qty, id]);
    }

    const orderNo = "XANZ-" + Date.now().toString(36).toUpperCase();
    const result = await conn.query(
      `INSERT INTO orders(order_no,user_id,customer_name,phone,address,total,status)
       VALUES(?,?,?,?,?,?,'pending')`,
      [orderNo, req.user.id, shipping.name.trim(), shipping.phone.trim(), shipping.address.trim(), total]
    );

    for (const i of normalized) {
      await conn.query(
        `INSERT INTO order_items(order_id,product_id,product_name,price,quantity,subtotal)
         VALUES(?,?,?,?,?,?)`,
        [result.insertId, i.productId, i.name, i.price, i.quantity, i.subtotal]
      );
    }

    await conn.commit();
    res.status(201).json({ orderNo, total, status: "pending" });
  } catch (e) {
    if (conn) await conn.rollback();
    res.status(400).json({ error: e.message || "สร้างคำสั่งซื้อไม่สำเร็จ" });
  } finally {
    if (conn) conn.release();
  }
});

app.get("/api/orders/me", auth, async (req, res) => {
  const orders = await db(
    "SELECT id,order_no,total,status,created_at FROM orders WHERE user_id=? ORDER BY id DESC",
    [req.user.id]
  );
  res.json(orders);
});

app.get("/api/admin/orders", auth, adminOnly, async (req, res) => {
  const rows = await db(
    `SELECT o.id,o.order_no,o.total,o.status,o.created_at,u.email
     FROM orders o JOIN users u ON u.id=o.user_id
     ORDER BY o.id DESC`
  );
  res.json(rows);
});

app.get("/api/admin/products", auth, adminOnly, async (req, res) => {
  res.json(await db("SELECT * FROM products ORDER BY id DESC"));
});

app.post("/api/admin/products", auth, adminOnly, async (req, res) => {
  const { name, category, price, image, stock, description } = req.body;
  if (!name || !category || Number(price) < 0 || Number(stock) < 0) {
    return res.status(400).json({ error: "ข้อมูลสินค้าไม่ถูกต้อง" });
  }
  const r = await db(
    `INSERT INTO products(name,category,price,image,stock,description)
     VALUES(?,?,?,?,?,?)`,
    [name, category, Number(price), image || "🛍️", Number(stock), description || ""]
  );
  res.status(201).json({ id: Number(r.insertId) });
});

app.patch("/api/admin/products/:id", auth, adminOnly, async (req, res) => {
  const { name, category, price, image, stock, description, active } = req.body;
  await db(
    `UPDATE products SET name=?,category=?,price=?,image=?,stock=?,description=?,active=?
     WHERE id=?`,
    [name, category, Number(price), image || "🛍️", Number(stock), description || "", active ? 1 : 0, Number(req.params.id)]
  );
  res.json({ ok: true });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`X-ANZ Shop running on http://localhost:${PORT}`));