CREATE DATABASE IF NOT EXISTS xanz_shop
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'xanz'@'localhost' IDENTIFIED BY 'change-me';
GRANT ALL PRIVILEGES ON xanz_shop.* TO 'xanz'@'localhost';
FLUSH PRIVILEGES;

USE xanz_shop;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','staff','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(180) NOT NULL,
  category VARCHAR(100) NOT NULL,
  price DECIMAL(12,2) NOT NULL,
  image VARCHAR(20) DEFAULT '🛍️',
  stock INT UNSIGNED NOT NULL DEFAULT 0,
  description TEXT,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_products_category(category),
  INDEX idx_products_active(active)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_no VARCHAR(40) NOT NULL UNIQUE,
  user_id BIGINT UNSIGNED NOT NULL,
  customer_name VARCHAR(100) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  address VARCHAR(500) NOT NULL,
  total DECIMAL(12,2) NOT NULL,
  status ENUM('pending','paid','processing','shipped','completed','cancelled') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  product_id BIGINT UNSIGNED NOT NULL,
  product_name VARCHAR(180) NOT NULL,
  price DECIMAL(12,2) NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

INSERT INTO products(name,category,price,image,stock,description) VALUES
('iPhone 15 Pro Max','มือถือ',45900,'📱',10,'สมาร์ตโฟนรุ่นเรือธง'),
('MacBook Pro M3','คอมพิวเตอร์',62900,'💻',5,'โน้ตบุ๊กสำหรับงานมืออาชีพ'),
('AirPods Pro 2','อุปกรณ์เสริม',8990,'🎧',20,'หูฟังไร้สาย'),
('Apple Watch Ultra 2','นาฬิกา',25900,'⌚',8,'สมาร์ตวอทช์'),
('iPad Pro 12.9','แท็บเล็ต',38900,'📲',7,'แท็บเล็ตประสิทธิภาพสูง'),
('Samsung Galaxy S24 Ultra','มือถือ',43900,'📱',15,'สมาร์ตโฟน Android'),
('Sony WH-1000XM5','เครื่องเสียง',13900,'🎧',12,'หูฟังตัดเสียงรบกวน'),
('Dell XPS 15','คอมพิวเตอร์',49900,'💻',6,'โน้ตบุ๊ก Dell'),
('LG OLED 65','ทีวี',89900,'📺',3,'ทีวี OLED'),
('Nintendo Switch OLED','เกมมิ่ง',11900,'🎮',9,'เครื่องเล่นเกม'),
('PlayStation 5','เกมมิ่ง',18900,'🎮',4,'เครื่องเล่นเกมคอนโซล'),
('Canon EOS R6','กล้อง',84900,'📷',2,'กล้อง Mirrorless')
ON DUPLICATE KEY UPDATE name=VALUES(name);